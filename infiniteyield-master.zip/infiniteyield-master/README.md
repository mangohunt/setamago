# Infinite Yield 
[![Discord](https://media.discordapp.net/attachments/338403017894395905/668536741942263808/Discord-Logo-Color.png)](https://discord.io/infiniteyield)
The best command line script for roblox.

Get it [here](https://github.com/EdgeIY/infiniteyield/wiki)

 - Currently 377 commands
 - Open Source
 - 6 years of development

## Developers
### Creator: Edge

### Developer: Moon
### Developer: Zwolf
### Developer: Toon


## Usage
You can learn how to use all the features of this script in the wiki!

## Contributing
There is no specific rules on contributing (as of now) just open a pull request and if it checks out we will merge it!
